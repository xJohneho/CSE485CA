package Locke;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.io.IOException;

import Locke.Cryption;
import Locke.PasswordManager;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception{
		Cryption test= new Cryption();
		PasswordManager test2 = new PasswordManager("Joker beat BATMAN!", 18);
		//String genPW = test2.generatePassword(10);
		String tester = "Hello";
		test.encryptToFIle(tester);
		test.encryptToFIle("Hello2");
		test.encryptToFIle("Hello3");
		test.encryptToFIle("Hello4");
		try {
			
			primaryStage.setTitle("Crypto");
			
			GridPane rootNode = new GridPane();
	        rootNode.setPadding(new Insets(15));
	        rootNode.setHgap(5);
	        rootNode.setVgap(5);
	        rootNode.setAlignment(Pos.CENTER);
	        
	        Scene myScene = new Scene(rootNode, 300, 300);
	        rootNode.add(new Label("Password:"), 0, 0);
	        TextField textField = new TextField();
	        //textField.appendText(genPW);
	        textField.appendText(test2.selfCreatePassword());
			rootNode.add(textField, 1, 0);
			Button aButton = new Button("Encrypt + Decrypt");
			rootNode.add(aButton, 1, 2);
	        GridPane.setHalignment(aButton, HPos.LEFT);
	        
	        rootNode.add(new Label("Encrypted:"), 0, 4);
	        TextField result = new TextField();
	        result.setEditable(false);
	        rootNode.add(new Label("Decrypted:"), 0, 5);
	        rootNode.add(result, 1, 4);
	        TextField result2 = new TextField();
	        result.setEditable(false);
	        rootNode.add(result2, 1, 5);
	        
	        aButton.setOnAction(e -> {
	        	String target = String.valueOf(textField.getText());
	            String encrypted;
				encrypted = test.encrypt(target);
	            String decrypted = test.decrypt(encrypted);
	            result.setText(encrypted);
	            result2.setText(decrypted);
	        });

			primaryStage.setScene(myScene);
			primaryStage.show();
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
