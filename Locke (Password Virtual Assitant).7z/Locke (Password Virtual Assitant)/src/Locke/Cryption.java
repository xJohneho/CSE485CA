package Locke;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import java.util.Base64;
   

public class Cryption {
	private static final String UNICODE_FORMAT = "UTF8";
    public static final String DESEDE_ENCRYPTION_FORMAT = "DESede";
    
    private String encKey;
    private String encFormat;
    private KeySpec kSpec;
    private SecretKeyFactory secretKeyFac;
    SecretKey key;
    private Cipher cipher;
    byte[] arrBytes;
    
    public Cryption() throws Exception {
        encKey = "TahtBaKpvrtdTadsOsSprfvz";
        encFormat = DESEDE_ENCRYPTION_FORMAT;
        arrBytes = encKey.getBytes(UNICODE_FORMAT);//Encode string as bytes
        kSpec = new DESedeKeySpec(arrBytes);
        secretKeyFac = SecretKeyFactory.getInstance(encFormat);
        cipher = Cipher.getInstance(encFormat);
        key = secretKeyFac.generateSecret(kSpec);
    }


    public String encrypt(String unencryptedString) {
        String encryptedString = null;
        try {
            cipher.init(Cipher.ENCRYPT_MODE, key);//Cipher is instantiated with Encrypt Mode
            byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);//Encode string as bytes
            byte[] encryptedText = cipher.doFinal(plainText);
            encryptedString = new String(Base64.getEncoder().encode(encryptedText));
               
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedString;
    }
    public byte[] encryptToFIle(String unencryptedString) {
    	String encryptedString = null;
    	try {
            cipher.init(Cipher.ENCRYPT_MODE, key);//Cipher is instantiated with Encrypt Mode
            byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);//Encode string as bytes
            byte[] encryptedText = cipher.doFinal(plainText);
            encryptedString = new String(Base64.getEncoder().encode(encryptedText));
            fileHandling(encryptedText);
            System.out.println(encryptedString); 
            return encryptedText;
        } catch (Exception e) {
            e.printStackTrace();
        }
    	
    }


    public String decrypt(String encryptedString) {
        String decryptedText = null;
        Path file = Paths.get("Encrypted");
        try {
            cipher.init(Cipher.DECRYPT_MODE, key);//Cipher is instantiated with Decrypt Mode
            byte[] encryptedText = Base64.getDecoder().decode(encryptedString);
            byte[] plainText = cipher.doFinal(encryptedText);
            Files.readAllBytes(file);
            decryptedText= new String(plainText);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryptedText;
    }
    public void fileHandling(byte[] test) throws IOException {
    	Path file = Paths.get("Encrypted");
        if(!Files.exists(file)){
        	System.out.println("Had to create new File");
        }
        Files.write(file, test);
    }
    
}