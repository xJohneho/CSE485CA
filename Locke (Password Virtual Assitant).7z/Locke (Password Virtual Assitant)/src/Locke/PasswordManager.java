package Locke;

import java.security.SecureRandom;

import org.apache.commons.lang3.RandomStringUtils;

public class PasswordManager {
	char[] possibleCharacters = (new String("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
											+ "abcdefghijklmnopqrstuvwxyz"
											+ "0123456789"
											+ "~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?"
											)).toCharArray();
	int strLength;
	String password;
	public PasswordManager(String pw, int pwLength){
		password = pw;
		strLength = pwLength;
	}
	
	public String generatePassword() {
		password = RandomStringUtils.random( strLength, 0, possibleCharacters.length-1, false, false, possibleCharacters, new SecureRandom() );
		return password;
	}
	public String selfCreatePassword() {
		return password;
	}
	public void passwordUpdater() {
		
	}
	public void deletePassword() {
		
	}

}
